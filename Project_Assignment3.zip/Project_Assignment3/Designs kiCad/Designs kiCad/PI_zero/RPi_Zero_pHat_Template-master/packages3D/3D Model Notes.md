## 3D Models
These models are not created by Mike Lawrence and have their own respective licenses and trademark. Please visit their web pages.
* `Samtec_HLE-120-02-xxx-DV-BE-A.stp` SMT Socket Strip [Samtec](https://www.samtec.com/products/hle-120-02-g-dv-be-a#).
